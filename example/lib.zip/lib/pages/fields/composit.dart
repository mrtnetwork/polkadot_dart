import 'package:example/api/interface.dart';
import 'package:example/form/form.dart';
import 'package:example/pages/fields/fields.dart';
import 'package:flutter/material.dart';

class CompositValidatorView extends StatefulWidget {
  const CompositValidatorView(
      {required this.metadata, required this.validator, super.key});
  final SubstrateIntractionAPi metadata;
  final MetadataCompositValidator validator;
  @override
  State<CompositValidatorView> createState() => _CompositValidatorViewState();
}

class _CompositValidatorViewState extends State<CompositValidatorView> {
  @override
  Widget build(BuildContext context) {
    return FieldsView(
        validators: widget.validator.validators, metadata: widget.metadata);
  }
}
