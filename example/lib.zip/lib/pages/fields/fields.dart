import 'package:example/api/interface.dart';
import 'package:example/form/form.dart';
import 'package:example/pages/fields/array.dart';
import 'package:flutter/material.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

import 'composit.dart';
import 'promitive.dart';
import 'tuple.dart';
import 'variant.dart';

class FieldView extends StatelessWidget {
  final MetadataTypeValidator validator;
  final SubstrateIntractionAPi metadata;
  const FieldView({required this.validator, required this.metadata, super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (validator.type.name != null) Text(validator.type.name!),
        switch (validator.metadataType) {
          MetadataTypes.bigInt ||
          MetadataTypes.boolean ||
          MetadataTypes.int ||
          MetadataTypes.none ||
          MetadataTypes.string =>
            PromitiveValidatorView(
              metadata: metadata,
              validator: validator as MetadataPromitiveValidator,
            ),
          MetadataTypes.array || MetadataTypes.sequence => ArrayValidatorView(
              metadata: metadata,
              validator: validator as MetadataArrayValidator,
            ),
          MetadataTypes.composit => CompositValidatorView(
              metadata: metadata,
              validator: validator as MetadataCompositValidator,
            ),
          MetadataTypes.tuple => TupleValidatorView(
              metadata: metadata,
              validator: validator as MetadataArrayValidator,
            ),
          MetadataTypes.variant => VariantValidatorView(
              metadata: metadata,
              validator: validator as MetadataVariantValidator,
            ),
          _ => const SizedBox()
        },
      ],
    );
  }
}

class FieldsView extends StatelessWidget {
  final List<MetadataTypeValidator<MetadataType>> validators;
  final SubstrateIntractionAPi metadata;
  const FieldsView(
      {required this.validators, required this.metadata, super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemBuilder: (context, index) {
          final type = validators[index];
          return FieldView(metadata: metadata, validator: type);
        },
        separatorBuilder: (context, index) => const Divider(),
        itemCount: validators.length);
  }
}
