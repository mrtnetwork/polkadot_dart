import 'package:example/api/interface.dart';
import 'package:example/form/form.dart';
import 'package:flutter/material.dart';

class ArrayValidatorView extends StatefulWidget {
  const ArrayValidatorView(
      {required this.metadata, required this.validator, super.key});
  final SubstrateIntractionAPi metadata;
  final MetadataArrayValidator validator;
  @override
  State<ArrayValidatorView> createState() => _ArrayValidatorViewState();
}

class _ArrayValidatorViewState extends State<ArrayValidatorView> {
  @override
  Widget build(BuildContext context) {
    return const Text("print array!");
  }
}
