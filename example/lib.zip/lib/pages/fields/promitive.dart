import 'package:example/api/interface.dart';
import 'package:example/form/form.dart';
import 'package:flutter/material.dart';

class PromitiveValidatorView extends StatefulWidget {
  const PromitiveValidatorView(
      {required this.metadata, required this.validator, super.key});
  final SubstrateIntractionAPi metadata;
  final MetadataPromitiveValidator validator;
  @override
  State<PromitiveValidatorView> createState() => _PromitiveValidatorViewState();
}

class _PromitiveValidatorViewState extends State<PromitiveValidatorView> {
  @override
  Widget build(BuildContext context) {
    return const TextField();
  }
}
