import 'package:example/api/interface.dart';
import 'package:example/form/form.dart';
import 'package:example/pages/fields/fields.dart';
import 'package:example/progress.dart';
import 'package:flutter/material.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

class VariantValidatorView extends StatefulWidget {
  const VariantValidatorView(
      {required this.metadata, required this.validator, super.key});
  final SubstrateIntractionAPi metadata;
  final MetadataVariantValidator validator;
  @override
  State<VariantValidatorView> createState() => _VariantValidatorViewState();
}

class _VariantValidatorViewState extends State<VariantValidatorView> {
  MetadataVariantValidator get validator => widget.validator;

  void onChangeVariant(Si1Variant? variant) {
    if (variant == null) return;
    if (variant == validator.variant) return;
    final validators = widget.metadata.variantToValidator(variant);
    validator.setVariant(variant: variant, validators: validators);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        DropdownButton(
            value: validator.variant,
            items: validator.variants.map((e) {
              return DropdownMenuItem(value: e, child: Text(e.name));
            }).toList(),
            onChanged: onChangeVariant),
        const SizedBox(height: 8),
        ConditionalWidget(widgets: {
          true: (context) => FieldsView(
              validators: validator.validators, metadata: widget.metadata)
        }, enable: validator.variant != null)
      ],
    );
  }
}
