import 'package:example/api/interface.dart';
import 'package:example/form/form.dart';
import 'package:flutter/material.dart';

class TupleValidatorView extends StatefulWidget {
  const TupleValidatorView(
      {required this.metadata, required this.validator, super.key});
  final SubstrateIntractionAPi metadata;
  final MetadataArrayValidator validator;
  @override
  State<TupleValidatorView> createState() => _TupleValidatorViewState();
}

class _TupleValidatorViewState extends State<TupleValidatorView> {
  @override
  Widget build(BuildContext context) {
    return const Text("is tupple");
  }
}
