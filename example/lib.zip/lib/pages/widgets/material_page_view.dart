import 'package:flutter/material.dart';

class MaterialPageView extends StatelessWidget {
  final Widget child;
  const MaterialPageView({required this.child, super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      child: SafeArea(child: child),
    );
  }
}
