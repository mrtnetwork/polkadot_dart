import 'package:flutter/material.dart';

extension QuickContextAcesss on BuildContext {
  Future<T?> toPage<T>(Widget page) async {
    if (mounted) {
      final push = await Navigator.push(
          this, MaterialPageRoute(builder: (context) => page));
      return (push as T?);
    }
    return null;
  }
}
