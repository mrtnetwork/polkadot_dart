import 'package:example/api/interface.dart';
import 'package:example/pages/pallets/method.dart';
import 'package:example/pages/tools/extentions.dart';
import 'package:example/pages/widgets/material_page_view.dart';
import 'package:flutter/material.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

class PalletCalls extends StatefulWidget {
  const PalletCalls(
      {required this.metadata, required this.palletName, super.key});
  final SubstrateIntractionAPi metadata;
  final String palletName;

  @override
  State<PalletCalls> createState() => _PalletCallsState();
}

class _PalletCallsState extends State<PalletCalls> {
  String get palletName => widget.palletName;
  SubstrateIntractionAPi get metadata => widget.metadata;
  List<PalletCallMethods> methods = [];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    methods = metadata.callMethods(palletName);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialPageView(
      child: CustomScrollView(
        slivers: [
          const SliverAppBar(
              title: Text("Methods"), pinned: true, floating: true),
          SliverList.separated(
            itemBuilder: (context, index) {
              final method = methods[index];
              return ListTile(
                title: Text(method.name),
                subtitle: method.docs == null ? null : Text(method.docs!),
                onTap: () {
                  context.toPage(MethodSerializationView(
                      method: method, metadata: metadata));
                },
              );
            },
            separatorBuilder: (context, index) => const Divider(),
            itemCount: methods.length,
          )
        ],
      ),
    );
  }
}
