import 'package:example/api/interface.dart';
import 'package:example/pages/widgets/material_page_view.dart';
import 'package:flutter/material.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

class StorageView extends StatefulWidget {
  const StorageView({required this.storage, required this.metadata, super.key});
  final PalletStorageMetadataV14 storage;
  final SubstrateIntractionAPi metadata;

  @override
  State<StorageView> createState() => _StorageViewState();
}

class _StorageViewState extends State<StorageView> {
  SubstrateIntractionAPi get metadata => widget.metadata;
  PalletStorageMetadataV14 get storage => widget.storage;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialPageView(
        child: CustomScrollView(
      slivers: [
        SliverAppBar(
          title: Text("Storage ${storage.prefix}"),
        ),
        SliverList.separated(
            itemBuilder: (context, index) {
              final type = storage.items[index];
              return Padding(
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: SelectableText(type.name),
              );
            },
            separatorBuilder: (context, index) => const Divider(),
            itemCount: storage.items.length),
      ],
    ));
  }
}
