import 'package:example/api/interface.dart';
import 'package:example/form/form.dart';
import 'package:example/pages/fields/fields.dart';
import 'package:example/pages/widgets/material_page_view.dart';
import 'package:flutter/material.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

class MethodSerializationView extends StatefulWidget {
  const MethodSerializationView(
      {required this.method, required this.metadata, super.key});
  final PalletCallMethods method;
  final SubstrateIntractionAPi metadata;

  @override
  State<MethodSerializationView> createState() =>
      _MethodSerializationViewState();
}

class _MethodSerializationViewState extends State<MethodSerializationView> {
  SubstrateIntractionAPi get metadata => widget.metadata;
  PalletCallMethods get method => widget.method;

  late List<MetadataTypeValidator> types;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    types = metadata.getTypesValidator(method.lookup, method.index);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialPageView(
        child: CustomScrollView(
      slivers: [
        SliverAppBar(
          title: Text(method.name),
        ),
        SliverList.separated(
            itemBuilder: (context, index) {
              final type = types[index];
              return Padding(
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: FieldView(metadata: metadata, validator: type),
              );
            },
            separatorBuilder: (context, index) => const Divider(),
            itemCount: types.length),
      ],
    ));
  }
}
