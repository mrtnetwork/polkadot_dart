import 'package:example/api/interface.dart';
import 'package:example/pages/pallets/pallet.dart';
import 'package:example/pages/tools/extentions.dart';
import 'package:flutter/material.dart';

class PalletsView extends StatelessWidget {
  const PalletsView(this.metadata, {super.key});
  final SubstrateIntractionAPi metadata;
  @override
  Widget build(BuildContext context) {
    return ListView.separated(
        shrinkWrap: true,
        itemBuilder: (context, index) => const Divider(),
        separatorBuilder: (context, index) {
          final String pallet = metadata.pallets[index];
          return ListTile(
            title: Text(metadata.pallets[index]),
            trailing: const Icon(Icons.arrow_forward),
            onTap: () {
              context
                  .toPage(PalletView(metadata: metadata, palletName: pallet));
            },
          );
        },
        itemCount: metadata.pallets.length);
  }
}
