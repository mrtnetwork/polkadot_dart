import 'package:example/api/interface.dart';
import 'package:example/pages/pallets/calls.dart';
import 'package:example/pages/pallets/storage.dart';
import 'package:example/pages/tools/extentions.dart';
import 'package:flutter/material.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

class PalletView extends StatefulWidget {
  const PalletView(
      {required this.metadata, required this.palletName, super.key});
  final SubstrateIntractionAPi metadata;
  final String palletName;

  @override
  State<PalletView> createState() => _PalletViewState();
}

class _PalletViewState extends State<PalletView> {
  late final PalletMetadata pallet =
      widget.metadata.api.metadata.getPallet(widget.palletName);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.palletName)),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Column(
              children: [
                ListTile(
                  title: const Text("Calls"),
                  onTap: pallet.calls == null
                      ? null
                      : () {
                          context.toPage(PalletCalls(
                              metadata: widget.metadata,
                              palletName: widget.palletName));
                        },
                ),
                ListTile(
                  title: const Text("Constants"),
                  onTap: pallet.constants.isEmpty ? null : () {},
                ),
                ListTile(
                  title: const Text("Storage"),
                  onTap: pallet.storage == null
                      ? null
                      : () {
                          context.toPage(StorageView(
                              metadata: widget.metadata,
                              storage: pallet.storage!));
                        },
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
