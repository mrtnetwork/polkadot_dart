import 'package:blockchain_utils/helper/helper.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

abstract class MetadataTypeValidator<T extends MetadataType> {
  final T type;
  MetadataTypes get metadataType => type.typeName;
  MetadataTypeValidator({required this.type});
  // T? _value;
  String? validate();
  // void setValue(T? value) {
  //   _value = value;
  // }
}

class MetadataArrayValidator<T>
    extends MetadataTypeValidator<MetadataSequence> {
  MetadataArrayValidator({required super.type});

  @override
  String? validate() {
    return "";
  }
}

class MetadataPromitiveValidator<T>
    extends MetadataTypeValidator<MetadataTypePromitive> {
  MetadataPromitiveValidator({required super.type});

  @override
  String? validate() {
    return "";
  }
}

class MetadataOptionValidator<T>
    extends MetadataTypeValidator<MetadataTypeOption> {
  MetadataOptionValidator({required this.validator, required super.type});
  final MetadataTypeValidator validator;

  @override
  String? validate() {
    return "";
  }
}

class MetadataTupleValidator extends MetadataTypeValidator<MetadataTypeTuple> {
  MetadataTupleValidator({required this.validators, required super.type});
  final List<MetadataTypeValidator> validators;

  @override
  String? validate() {
    return "";
  }
}

class MetadataCompositValidator
    extends MetadataTypeValidator<MetadataTypeComposit> {
  MetadataCompositValidator({required this.validators, required super.type});
  final List<MetadataTypeValidator> validators;

  @override
  String? validate() {
    return "";
  }
}

class MetadataVariantValidator
    extends MetadataTypeValidator<MetadataTypeVariant> {
  MetadataVariantValidator({required super.type});
  List<Si1Variant> get variants => type.variants;
  List<MetadataTypeValidator> _validators = [];
  List<MetadataTypeValidator> get validators => _validators;
  Si1Variant? _variant;
  Si1Variant? get variant => _variant;

  void setVariant({
    required Si1Variant? variant,
    required List<MetadataTypeValidator> validators,
  }) {
    if (!variants.contains(variant)) return;
    _variant = variant;
    _validators = validators.immutable;
  }

  @override
  String? validate() {
    return "";
  }
}
// class MetadataListValidator extends 