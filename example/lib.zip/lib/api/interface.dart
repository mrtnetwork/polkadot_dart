import 'package:example/examples/json_rpc_example.dart';
import 'package:example/form/form.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

class SubstrateIntractionAPi {
  final SubstrateProvider provider;
  final MetadataApi api;
  SubstrateIntractionAPi._({required this.provider, required this.api});
  static Future<SubstrateIntractionAPi> latest(
      {String url = "https://westmint-rpc.dwellir.com:443"}) async {
    final provider = SubstrateProvider(SubstrateHttpService(url));
    final currentMetadata = await provider
        .request(const SubstrateRequestRuntimeMetadataGetMetadataAtVersion(15));
    final api = currentMetadata!.toApi();
    return SubstrateIntractionAPi._(provider: provider, api: api);
  }

  static Future<SubstrateIntractionAPi> fromHex(
      {required String metadataHex,
      String url = "https://westend-rpc.polkadot.io"}) async {
    final provider = SubstrateProvider(SubstrateHttpService(url));
    final currentMetadata = VersionedMetadata.fromHex(metadataHex);
    final api = currentMetadata.toApi();
    return SubstrateIntractionAPi._(provider: provider, api: api);
  }

  late List<String> pallets = api.getPalletNames();

  List<PalletCallMethods> callMethods(String palletNameOrIndex) {
    return api.metadata.getCalls(palletNameOrIndex);
  }

  List<MetadataType> getMetadataType(int lookupId, int index) {
    final type = api.registry.scaleType(lookupId).def.cast<Si1TypeDefVariant>();
    final v = type.variants.firstWhere((e) => e.index == index);
    return v.fields.map((e) => e.toType(api.registry, e.type)).toList();
  }

  List<MetadataTypeValidator> variantToValidator(Si1Variant variant) {
    final types = variant.fields
        .map((e) => _findValidator(e.toType(api.registry, e.type)))
        .toList();
    return types;
  }

  List<MetadataTypeValidator> getTypesValidator(int lookupId, int index) {
    final type = api.registry.scaleType(lookupId).def.cast<Si1TypeDefVariant>();
    final v = type.variants.firstWhere((e) => e.index == index);
    return variantToValidator(v);
  }

  MetadataTypeValidator _findValidator(MetadataType type) {
    switch (type.typeName) {
      case MetadataTypes.none:
        return MetadataPromitiveValidator<void>(type: type.cast());
      case MetadataTypes.boolean:
        return MetadataPromitiveValidator<bool>(type: type.cast());
      case MetadataTypes.string:
        return MetadataPromitiveValidator<String>(type: type.cast());
      case MetadataTypes.int:
        return MetadataPromitiveValidator<int>(type: type.cast());
      case MetadataTypes.option:
        final validator = _findValidator(type.cast<MetadataTypeOption>().type);
        return MetadataOptionValidator(type: type.cast(), validator: validator);
      case MetadataTypes.bigInt:
        return MetadataPromitiveValidator<BigInt>(type: type.cast());
      case MetadataTypes.array:
      case MetadataTypes.sequence:
        return MetadataArrayValidator<BigInt>(type: type.cast());
      case MetadataTypes.tuple:
        final validators = type
            .cast<MetadataTypeTuple>()
            .types
            .map((e) => _findValidator(e))
            .toList();
        return MetadataTupleValidator(
            validators: validators, type: type.cast());
      case MetadataTypes.composit:
        final validators = type
            .cast<MetadataTypeComposit>()
            .types
            .map((e) => _findValidator(e))
            .toList();
        return MetadataCompositValidator(
            validators: validators, type: type.cast());
      case MetadataTypes.variant:
        return MetadataVariantValidator(type: type.cast());
      default:
        throw Exception("invalid type");
    }
  }
}
